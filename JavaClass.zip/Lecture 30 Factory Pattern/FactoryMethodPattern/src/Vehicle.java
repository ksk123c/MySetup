
public interface Vehicle {
	
	public void startEngine();

}
