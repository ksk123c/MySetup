package devices;

public interface Device {
	void turnOn();
	void turnOff();
	
}
