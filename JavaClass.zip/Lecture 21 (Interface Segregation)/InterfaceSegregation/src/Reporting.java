import java.util.Date;

public interface Reporting {

	// methods for reporting
	public String getName();

	public Date getDate();

	public String productBreakDown();

}